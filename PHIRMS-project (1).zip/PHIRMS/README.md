# PHIRMS – professional camera for Android

Native Kotlin + Camera2, no third-party dependencies. App ID `com.phrms.camera`, minSdk 29, targetSdk 34.
Independent code and branding (the F-in-lens icon is original). Not affiliated with Blackmagic Design.

## Get the APK (no local build needed)
1. Create an empty GitHub repository.
2. Unzip this project and push its contents (the `.github` folder must be at the repo root):
   `git init && git add -A && git commit -m "PHIRMS" && git branch -M main && git remote add origin <your-repo-url> && git push -u origin main`
3. Open the repo's **Actions** tab → *Build PHIRMS APK* → wait for the green check (or press **Run workflow**).
4. Open the finished run → **Artifacts** → download `PHIRMS-debug-apk`, unzip it, and copy `app-debug.apk` to your phone.
5. On the phone allow "Install unknown apps" for your file manager/browser, then open the APK. Or: `adb install -r app-debug.apk`.

The debug APK is signed with the standard Android debug key, so it installs directly.

## Local build (optional)
JDK 17, Android SDK (platform 34), Gradle 8.7: `gradle --no-daemon assembleDebug`.

## What is in the code
| Area | Status |
|---|---|
| Camera2 preview, front/rear, lens list (physical IDs the device exposes) | Implemented, **not yet run on a device** |
| Photo (JPEG → Pictures/PHIRMS via MediaStore) | Implemented, not yet run |
| Video (MediaRecorder, H.264/HEVC if encoder exists, bitrate, 24/25/30/60 fps and 16:9 sizes filtered by hardware limits, AAC audio, Movies/PHIRMS) | Implemented, not yet run |
| Manual ISO, shutter (≤ 1/fps), focus distance, EV, zoom (pinch), WB presets, OIS/EIS | Implemented; each shown only if the camera reports support. Telemetry shows values reported back by the camera |
| Tap-to-focus/meter | Implemented, not yet run |
| Histogram, waveform, zebra (≥ ~94 % luma), focus peaking, grids/safe areas, audio meter | Implemented (one shared 320×180 analysis pass, ~5 Hz, skips frames when busy), not yet run |
| Storage/thermal safeguards | Stops recording under 150 MB free or at critical thermal status |
| Persistent settings | Implemented |

Not implemented: pause/resume, Kelvin/tint white balance, RAW/log/HDR/10-bit, camera presets, in-app gallery, external-mic selection, headphone monitoring, analysis during 4K at high load tuning.
Known simplifications: UI is landscape-locked; front preview is not mirrored; audio is whatever channel layout MediaRecorder picks; photo size matches the video aspect (16:9) while recording is off.

## Test plan (to run on the Galaxy S10)
Permissions on first launch; rear/front/lens switching; 1080p30 and 4K30 recording → playback with audio sync; orientation in both landscape directions (photo + video); manual ISO/shutter/focus reported values; unsupported-setting toasts; home/lock/incoming call during recording; low storage; repeated 10× record cycles; `adb logcat -s PHIRMS`.

## v0.2 changes
- Portrait and landscape both supported (orientation locks while recording so the file is correct).
- Top bar has only the essentials; **SETTINGS** holds resolution, fps, codec, bitrate, white balance, stabilization, look, grid and monitors.
- Manual controls (exposure/shutter/ISO/focus/EV) are hidden until you tap **CTRL**.
- **VIDEO / PHOTO** switch; the big button records or takes a picture. **LAST** opens the latest file.
- **LOOK**: CONTRAST, TEAL-ORANGE, WARM, COOL, FADED (tone-curve) plus B&W/SEPIA/etc. — only the ones the camera reports as supported are listed, and a device may ignore them. Not verified on the S10.
- 4K: pick **4K** with RES, then 25 or 30 fps. Only offered if the camera reports 2160p for video.
