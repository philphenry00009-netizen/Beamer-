package com.phrms.camera

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.ContentValues
import android.content.Intent
import android.content.pm.ActivityInfo
import android.content.res.Configuration
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SurfaceTexture
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.hardware.camera2.*
import android.hardware.camera2.params.MeteringRectangle
import android.hardware.camera2.params.TonemapCurve
import android.hardware.display.DisplayManager
import android.media.ImageReader
import android.media.MediaCodecList
import android.media.MediaRecorder
import android.net.Uri
import android.os.*
import android.provider.MediaStore
import android.util.Log
import android.util.Range
import android.util.Size
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Semaphore
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.math.*

class MainActivity : Activity() {
    private val tag = "PHIRMS"
    private lateinit var cm: CameraManager
    private lateinit var frame: AspectFrame
    private lateinit var tv: TextureView
    private lateinit var overlay: OverlayView
    private lateinit var analyzer: Analyzer
    private lateinit var status: TextView
    private lateinit var bSet: Button; private lateinit var bMode: Button; private lateinit var bCam: Button
    private lateinit var bLens: Button; private lateinit var bRes: Button; private lateinit var bFps: Button
    private lateinit var bLook: Button; private lateinit var bCtrl: Button; private lateinit var bExp: Button
    private lateinit var bFocus: Button; private lateinit var mainBtn: Button; private lateinit var panel: LinearLayout
    private lateinit var sIso: SeekBar; private lateinit var sShut: SeekBar
    private lateinit var sFocus: SeekBar; private lateinit var sEv: SeekBar
    private lateinit var tIso: TextView; private lateinit var tShut: TextView
    private lateinit var tFocus: TextView; private lateinit var tEv: TextView

    private val audioMeter = AudioMeter { overlay.audio = it }
    private val prefs by lazy { getSharedPreferences("phirms", MODE_PRIVATE) }
    private val ui = Handler(Looper.getMainLooper())
    private var bgThread: HandlerThread? = null
    private var bg: Handler? = null
    private val openLock = Semaphore(1)
    private val lockHeld = AtomicBoolean(false)

    private var camera: CameraDevice? = null
    private var session: CameraCaptureSession? = null
    private var chars: CameraCharacteristics? = null
    private var builder: CaptureRequest.Builder? = null
    private var jpegReader: ImageReader? = null

    // user settings
    private var facing = CameraCharacteristics.LENS_FACING_BACK
    private var lensIdx = 0
    private var fps = 30
    private var resH = 1080
    private var hevc = false
    private var mbps = 20
    private var wbIdx = 0
    private var stabIdx = 0
    private var manualExp = false
    private var manualFocus = false
    private var iso = 100
    private var expNs = 16_666_666L
    private var focusP = 0f
    private var evIdx = 0
    private var zoom = 1f
    private var regions: Array<MeteringRectangle>? = null

    // capabilities of the open camera
    private var videoSizes = listOf<Size>()
    private var videoSize = Size(1920, 1080)
    private var previewSize = Size(1920, 1080)
    private var photoSize = Size(1920, 1080)
    private var fpsList = listOf(30)
    private var manualOk = false
    private var isoRange = Range(100, 100)
    private var expRange = Range(1_000_000L, 1_000_000L)
    private var minFocus = 0f
    private var evRange = Range(0, 0)
    private var evStep = 0f
    private var maxZoom = 1f
    private var maxAf = 0
    private var maxAe = 0
    private var wbModes = listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB")
    private var stabOpts = listOf("OFF")
    private var lensLabel = "LENS"
    private var looks = listOf("OFF")
    private var lookIdx = 0
    private var photoMode = false
    private var showPanel = false
    private var lastUri: Uri? = null
    private var lastMime = "video/mp4"
    private val hevcOk by lazy { encoderExists("video/hevc") }

    // recording
    @Volatile private var recording = false
    private var recorder: MediaRecorder? = null
    private var recUri: Uri? = null
    private var recPfd: ParcelFileDescriptor? = null
    private var recStart = 0L
    @Volatile private var tel = ""
    private var lastTel = 0L
    private var tickN = 0
    private var scaled = false

    private val frameNs get() = (1e9 / fps).toLong()
    private fun hasPerm(p: String) = checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
    private fun toast(s: String) = runOnUiThread { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun cam(block: () -> Unit) {
        bg?.post { try { block() } catch (e: Exception) { Log.e(tag, "camera op failed", e); toast("Error: ${e.message}") } }
    }

    // ───────────────────────── lifecycle ─────────────────────────
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        cm = getSystemService(CAMERA_SERVICE) as CameraManager
        loadPrefs()
        buildUi()
        if (!hasPerm(Manifest.permission.CAMERA) || !hasPerm(Manifest.permission.RECORD_AUDIO))
            requestPermissions(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO), 1)
    }

    override fun onResume() {
        super.onResume()
        bgThread = HandlerThread("phirms-cam").also { it.start() }
        bg = Handler(bgThread!!.looper)
        if (hasPerm(Manifest.permission.CAMERA) && tv.isAvailable) cam { openCamera() }
        if (hasPerm(Manifest.permission.RECORD_AUDIO)) audioMeter.start()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).registerDisplayListener(displayListener, null)
        ui.post(ticker)
    }

    override fun onPause() {
        ui.removeCallbacks(ticker)
        savePrefs()
        (getSystemService(DISPLAY_SERVICE) as DisplayManager).unregisterDisplayListener(displayListener)
        audioMeter.stop()
        bg?.post { try { stopRecording(false); closeCamera() } catch (e: Exception) { Log.e(tag, "pause", e) } }
        bgThread?.quitSafely()
        try { bgThread?.join(4000) } catch (e: Exception) {}
        bgThread = null; bg = null
        super.onPause()
    }

    @Suppress("DEPRECATION")
    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
    }

    private val displayListener = object : DisplayManager.DisplayListener {
        override fun onDisplayAdded(id: Int) {}
        override fun onDisplayRemoved(id: Int) {}
        override fun onDisplayChanged(id: Int) { runOnUiThread { applyTransform() } }
    }

    private val ticker = object : Runnable {
        override fun run() {
            tickN++
            if (recording) overlay.audio = try { (recorder?.maxAmplitude ?: 0) / 32768f } catch (e: Exception) { 0f }
            if (tickN % 2 == 0) analyzer.tick()
            if (tickN % 10 == 0) checkLimits()
            if (tickN % 3 == 0) {
                val t = if (recording) (SystemClock.elapsedRealtime() - recStart) / 1000 else -1
                val rec = if (t >= 0) String.format(Locale.US, "● REC %02d:%02d:%02d  ", t / 3600, t / 60 % 60, t % 60) else ""
                status.text = rec + tel
            }
            overlay.invalidate()
            ui.postDelayed(this, 100)
        }
    }

    private fun checkLimits() {
        val free = freeBytes()
        val thermal = (getSystemService(POWER_SERVICE) as PowerManager).currentThermalStatus
        if (recording && free < 150L * 1024 * 1024) { toast("Storage almost full – stopping"); cam { stopRecording() } }
        if (recording && thermal >= PowerManager.THERMAL_STATUS_CRITICAL) { toast("Device too hot – stopping"); cam { stopRecording() } }
        else if (thermal >= PowerManager.THERMAL_STATUS_SEVERE && tickN % 100 == 0) toast("Device is very warm")
    }

    @Suppress("DEPRECATION")
    private fun freeBytes() = StatFs(Environment.getExternalStorageDirectory().path).availableBytes

    // ───────────────────────── UI ─────────────────────────
    @Suppress("DEPRECATION")
    private fun rotation() = windowManager.defaultDisplay.rotation
    private fun isLand() = rotation().let { it == Surface.ROTATION_90 || it == Surface.ROTATION_270 }

    private fun buildUi() {
        val land = resources.configuration.orientation == Configuration.ORIENTATION_LANDSCAPE
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        frame = AspectFrame(this)
        tv = TextureView(this)
        overlay = OverlayView(this)
        frame.addView(tv, FrameLayout.LayoutParams(-1, -1))
        frame.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        root.addView(frame, FrameLayout.LayoutParams(-1, -1, Gravity.CENTER))
        analyzer = Analyzer(tv, overlay)
        overlay.showHist = prefs.getBoolean("hist", false); overlay.showWave = prefs.getBoolean("wave", false)
        analyzer.zebra = prefs.getBoolean("zebra", false); analyzer.peak = prefs.getBoolean("peak", false)
        overlay.grid = prefs.getInt("grid", 0)

        tv.surfaceTextureListener = object : TextureView.SurfaceTextureListener {
            override fun onSurfaceTextureAvailable(st: SurfaceTexture, w: Int, h: Int) {
                applyTransform(); if (hasPerm(Manifest.permission.CAMERA)) cam { openCamera() }
            }
            override fun onSurfaceTextureSizeChanged(st: SurfaceTexture, w: Int, h: Int) { applyTransform() }
            override fun onSurfaceTextureDestroyed(st: SurfaceTexture) = true
            override fun onSurfaceTextureUpdated(st: SurfaceTexture) {}
        }
        val sd = ScaleGestureDetector(this, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                zoom = (zoom * d.scaleFactor).coerceIn(1f, maxZoom); scaled = true; refresh(); return true
            }
        })
        frame.setOnTouchListener { v, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) scaled = false
            sd.onTouchEvent(e)
            if (e.actionMasked == MotionEvent.ACTION_UP && !scaled && e.pointerCount == 1) tapFocus(e.x / v.width, e.y / v.height)
            true
        }

        // top bar: essentials only; everything else lives in Settings
        val row = LinearLayout(this)
        bSet = btn(row) { showSettings() }
        bMode = btn(row) { photoMode = !photoMode; labels() }
        bCam = btn(row) { cam { switchCamera(true) } }
        bLens = btn(row) { cam { switchCamera(false) } }
        bRes = btn(row) { cycleRes() }
        bFps = btn(row) { cycleFps() }
        bLook = btn(row) { cycleLook() }
        bCtrl = btn(row) {
            showPanel = !showPanel
            panel.visibility = if (showPanel) View.VISIBLE else View.GONE
            labels()
        }
        val scroll = HorizontalScrollView(this).apply { setBackgroundColor(0x99000000.toInt()); isHorizontalScrollBarEnabled = false; addView(row) }
        root.addView(scroll, FrameLayout.LayoutParams(-1, -2, Gravity.TOP))
        status = TextView(this).apply { setTextColor(Color.WHITE); textSize = 11f; typeface = Typeface.MONOSPACE; setShadowLayer(3f, 0f, 0f, Color.BLACK) }
        root.addView(status, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.START).apply { topMargin = dp(40); leftMargin = dp(24) })

        // manual panel (hidden until CTRL is tapped)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setBackgroundColor(0xCC000000.toInt()); setPadding(dp(8), dp(4), dp(8), dp(4))
            visibility = if (showPanel) View.VISIBLE else View.GONE
        }
        val prow = LinearLayout(this)
        bExp = btn(prow) {
            if (!manualOk) toast("Manual exposure not supported by this camera") else { manualExp = !manualExp; refresh(); labels(); syncSliders() }
        }
        bFocus = btn(prow) {
            if (minFocus <= 0f) toast("Manual focus not supported by this camera") else { manualFocus = !manualFocus; refresh(); labels() }
        }
        panel.addView(prow)
        val srow = LinearLayout(this)
        val a = slider(srow) { p ->
            val lo = ln(isoRange.lower.toDouble()); val hi = ln(isoRange.upper.toDouble())
            iso = exp(lo + (hi - lo) * p).roundToInt().coerceIn(isoRange.lower, isoRange.upper)
        }; sIso = a.first; tIso = a.second
        val b2 = slider(srow) { p ->
            val lo = ln(shutMin().toDouble()); val hi = ln(shutMax().toDouble())
            expNs = exp(lo + (hi - lo) * p).toLong()
        }; sShut = b2.first; tShut = b2.second
        val c = slider(srow) { p -> focusP = p.toFloat() }; sFocus = c.first; tFocus = c.second
        val d = slider(srow) { p -> evIdx = (evRange.lower + (evRange.upper - evRange.lower) * p).roundToInt() }; sEv = d.first; tEv = d.second
        panel.addView(srow)

        // main button: records in VIDEO mode, takes a picture in PHOTO mode
        mainBtn = circle(Color.RED, 68) { if (photoMode) takePhoto() else toggleRecord() }
        val lastBtn = Button(this).apply {
            setAllCaps(false); text = "LAST"; textSize = 11f; setTextColor(Color.WHITE); setBackgroundColor(0x66000000)
            minHeight = 0; minimumHeight = 0; setOnClickListener { openLast() }
        }
        if (land) {
            val right = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER }
            right.addView(mainBtn)
            right.addView(lastBtn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(16) })
            root.addView(right, FrameLayout.LayoutParams(dp(100), -1, Gravity.END))
            root.addView(panel, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { rightMargin = dp(100) })
        } else {
            val ctl = LinearLayout(this).apply { gravity = Gravity.CENTER; setPadding(0, dp(4), 0, dp(16)); setBackgroundColor(0x66000000) }
            ctl.addView(lastBtn, LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(32) })
            ctl.addView(mainBtn)
            val bottom = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            bottom.addView(panel); bottom.addView(ctl)
            root.addView(bottom, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM))
        }
        setContentView(root)
        labels()
    }

    private fun btn(parent: LinearLayout, onClick: () -> Unit): Button {
        val b = Button(this).apply {
            setAllCaps(false); textSize = 11f; minWidth = 0; minimumWidth = 0; minHeight = 0; minimumHeight = 0
            setPadding(dp(10), dp(6), dp(10), dp(6)); setBackgroundColor(Color.TRANSPARENT); setTextColor(Color.WHITE)
            setOnClickListener { onClick() }
        }
        parent.addView(b, LinearLayout.LayoutParams(-2, dp(34)))
        return b
    }

    private fun circle(color: Int, size: Int, onClick: () -> Unit) = Button(this).apply {
        background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(color); setStroke(dp(3), Color.WHITE) }
        layoutParams = LinearLayout.LayoutParams(dp(size), dp(size)).apply { topMargin = dp(12) }
        setOnClickListener { onClick() }
    }

    private fun slider(parent: LinearLayout, onP: (Double) -> Unit): Pair<SeekBar, TextView> {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val t = TextView(this).apply { setTextColor(Color.WHITE); textSize = 10f; typeface = Typeface.MONOSPACE; gravity = Gravity.CENTER }
        val s = SeekBar(this).apply { max = 1000 }
        s.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                if (!fromUser) return
                onP(p / 1000.0); refresh(); labels()
            }
            override fun onStartTrackingTouch(sb: SeekBar) {}
            override fun onStopTrackingTouch(sb: SeekBar) {}
        })
        box.addView(t); box.addView(s)
        parent.addView(box, LinearLayout.LayoutParams(0, -2, 1f).apply { marginStart = dp(4); marginEnd = dp(4) })
        return s to t
    }

    private fun shutMin() = max(expRange.lower, 125_000L)
    private fun shutMax() = max(shutMin() + 1, min(frameNs, expRange.upper))

    private fun labels() {
        fun on(b: Button, v: Boolean, t: String) { b.text = t; b.setTextColor(if (v) 0xFF66FF99.toInt() else Color.WHITE) }
        on(bSet, false, "SETTINGS"); on(bMode, photoMode, if (photoMode) "PHOTO" else "VIDEO")
        on(bCam, false, if (facing == CameraCharacteristics.LENS_FACING_FRONT) "FRONT" else "REAR")
        on(bLens, false, lensLabel); on(bRes, false, if (resH >= 2160) "4K" else "${resH}p"); on(bFps, false, "${fps}fps")
        on(bLook, lookIdx != 0, "LOOK " + looks[lookIdx.coerceIn(0, looks.size - 1)]); on(bCtrl, showPanel, "CTRL")
        on(bExp, manualExp, if (manualExp) "EXP:MAN" else "EXP:AUTO"); on(bFocus, manualFocus, if (manualFocus) "MF" else "AF")
        tIso.text = "ISO " + (if (manualExp) "$iso" else "AUTO")
        tShut.text = if (manualExp) "1/${(1e9 / expNs.coerceIn(shutMin(), shutMax())).roundToInt()}  ${(expNs.coerceIn(shutMin(), shutMax()) * 360.0 / frameNs).roundToInt()}°" else "SHUTTER AUTO"
        tFocus.text = if (manualFocus) "FOCUS " + (if (focusP <= 0.01f) "INF" else String.format(Locale.US, "%.2fm", 1f / (focusP * minFocus))) else "FOCUS AUTO"
        tEv.text = if (manualExp) "EV –" else String.format(Locale.US, "EV %+.1f", evIdx * evStep)
        sIso.isEnabled = manualExp; sShut.isEnabled = manualExp; sEv.isEnabled = !manualExp; sFocus.isEnabled = manualFocus
        if (!recording) (mainBtn.background as GradientDrawable).setColor(if (photoMode) Color.WHITE else Color.RED)
    }

    private fun syncSliders() {
        fun lp(v: Double, a: Double, b: Double) = if (b > a) ((ln(v) - ln(a)) / (ln(b) - ln(a)) * 1000).toInt().coerceIn(0, 1000) else 0
        sIso.progress = lp(iso.toDouble(), isoRange.lower.toDouble(), isoRange.upper.toDouble())
        sShut.progress = lp(expNs.toDouble().coerceIn(shutMin().toDouble(), shutMax().toDouble()), shutMin().toDouble(), shutMax().toDouble())
        sFocus.progress = (focusP * 1000).toInt()
        sEv.progress = if (evRange.upper > evRange.lower) ((evIdx - evRange.lower) * 1000 / (evRange.upper - evRange.lower)) else 0
        labels()
    }

    private fun setRecUi(rec: Boolean) {
        val d = mainBtn.background as GradientDrawable
        d.shape = if (rec) GradientDrawable.RECTANGLE else GradientDrawable.OVAL
        d.cornerRadius = if (rec) dp(10).toFloat() else 0f
        d.setColor(if (rec) Color.RED else if (photoMode) Color.WHITE else Color.RED)
        for (b in listOf(bCam, bLens, bRes, bFps, bSet, bMode)) b.isEnabled = !rec
        // keep the orientation fixed while recording so the file orientation stays correct
        requestedOrientation = if (rec) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_FULL_SENSOR
        if (rec) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun setFrameAspect() {
        if (isLand()) frame.setAspect(previewSize.width, previewSize.height) else frame.setAspect(previewSize.height, previewSize.width)
    }

    /** Same transform as Google's Camera2Basic sample: portrait needs none, landscape needs un-rotating. */
    private fun applyTransform() {
        setFrameAspect()
        val vw = tv.width.toFloat(); val vh = tv.height.toFloat()
        if (vw == 0f || vh == 0f) return
        val cx = vw / 2f; val cy = vh / 2f
        val m = Matrix()
        val rot = rotation()
        if (rot == Surface.ROTATION_90 || rot == Surface.ROTATION_270) {
            val buf = RectF(0f, 0f, previewSize.height.toFloat(), previewSize.width.toFloat())
            buf.offset(cx - buf.centerX(), cy - buf.centerY())
            m.setRectToRect(RectF(0f, 0f, vw, vh), buf, Matrix.ScaleToFit.FILL)
            val s = max(vh / previewSize.height, vw / previewSize.width)
            m.postScale(s, s, cx, cy)
            m.postRotate(90f * (rot - 2), cx, cy)
        } else if (rot == Surface.ROTATION_180) m.postRotate(180f, cx, cy)
        tv.setTransform(m)
    }

    private fun cycleLook() { lookIdx = (lookIdx + 1) % looks.size; refresh(); labels() }

    private fun openLast() {
        val u = lastUri
        if (u == null) { toast("Nothing captured yet"); return }
        try {
            startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(u, lastMime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
        } catch (e: Exception) { toast("No app found to open it") }
    }

    private fun showSettings() {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(12), dp(8), dp(12), dp(8)) }
        fun row(label: String, value: () -> String, tap: () -> Unit) {
            val b = Button(this)
            fun upd() { b.text = "$label:  ${value()}" }
            b.setOnClickListener { tap(); upd(); labels() }
            upd(); col.addView(b, LinearLayout.LayoutParams(-1, -2))
        }
        row("Resolution", { if (resH >= 2160) "4K (2160p)" else "${resH}p" }) { cycleRes() }
        row("Frame rate", { "$fps fps" }) { cycleFps() }
        row("Codec", { if (hevc) "HEVC (H.265)" else "AVC (H.264)" }) { if (hevcOk) { hevc = !hevc } else { toast("No HEVC encoder on this device") } }
        row("Bitrate", { "$mbps Mbps" }) { mbps = when (mbps) { 10 -> 20; 20 -> 40; 40 -> 80; else -> 10 } }
        row("White balance", { wbModes[wbIdx.coerceIn(0, wbModes.size - 1)].second }) { wbIdx = (wbIdx + 1) % wbModes.size; refresh() }
        row("Stabilization", { stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)] }) { stabIdx = (stabIdx + 1) % stabOpts.size; refresh() }
        row("Look / filter", { looks[lookIdx.coerceIn(0, looks.size - 1)] }) { cycleLook() }
        row("Grid", { listOf("OFF", "THIRDS", "GUIDES")[overlay.grid] }) { overlay.grid = (overlay.grid + 1) % 3 }
        row("Histogram", { if (overlay.showHist) "ON" else "OFF" }) { overlay.showHist = !overlay.showHist }
        row("Waveform", { if (overlay.showWave) "ON" else "OFF" }) { overlay.showWave = !overlay.showWave }
        row("Zebra", { if (analyzer.zebra) "ON" else "OFF" }) { analyzer.zebra = !analyzer.zebra }
        row("Focus peaking", { if (analyzer.peak) "ON" else "OFF" }) { analyzer.peak = !analyzer.peak }
        col.addView(TextView(this).apply {
            text = "Videos: Movies/PHIRMS\nPhotos: Pictures/PHIRMS\nLooks that this phone's camera does not support are not listed."
            setPadding(dp(8), dp(12), dp(8), dp(4))
        })
        AlertDialog.Builder(this).setTitle("PHIRMS settings")
            .setView(ScrollView(this).apply { addView(col) }).setPositiveButton("Close", null).show()
    }

    // ───────────────────────── prefs ─────────────────────────
    private fun loadPrefs() = prefs.run {
        fps = getInt("fps", 30); resH = getInt("resH", 1080); hevc = getBoolean("hevc", false); mbps = getInt("mbps", 20)
        wbIdx = getInt("wb", 0); stabIdx = getInt("stab", 0); manualExp = getBoolean("mexp", false); manualFocus = getBoolean("mf", false)
        facing = getInt("facing", CameraCharacteristics.LENS_FACING_BACK); lensIdx = getInt("lens", 0)
        lookIdx = getInt("look", 0); photoMode = getBoolean("photo", false)
    }

    private fun savePrefs() = prefs.edit().apply {
        putInt("fps", fps); putInt("resH", resH); putBoolean("hevc", hevc); putInt("mbps", mbps); putInt("wb", wbIdx); putInt("stab", stabIdx)
        putBoolean("mexp", manualExp); putBoolean("mf", manualFocus); putInt("facing", facing); putInt("lens", lensIdx)
        putInt("look", lookIdx); putBoolean("photo", photoMode)
        putBoolean("hist", overlay.showHist); putBoolean("wave", overlay.showWave); putBoolean("zebra", analyzer.zebra)
        putBoolean("peak", analyzer.peak); putInt("grid", overlay.grid)
    }.apply()

    // ───────────────────────── camera ─────────────────────────
    private val stateCb = object : CameraDevice.StateCallback() {
        override fun onOpened(c: CameraDevice) { unlock(); camera = c; cam { startPreview() } }
        override fun onDisconnected(c: CameraDevice) { unlock(); c.close(); camera = null }
        override fun onError(c: CameraDevice, e: Int) {
            unlock(); c.close(); camera = null; toast("Camera error $e")
            if (recording) cam { stopRecording(false) }
        }
    }

    private fun unlock() { if (lockHeld.getAndSet(false)) openLock.release() }

    private fun lensIds(): List<String> = cm.cameraIdList.filter {
        val c = cm.getCameraCharacteristics(it)
        c.get(CameraCharacteristics.LENS_FACING) == facing &&
            (c.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_BACKWARD_COMPATIBLE) ?: true)
    }

    @Suppress("MissingPermission")
    private fun openCamera() {
        if (camera != null || !hasPerm(Manifest.permission.CAMERA) || !tv.isAvailable) return
        if (!openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)) { toast("Camera busy"); return }
        lockHeld.set(true)
        try {
            val ids = lensIds()
            if (ids.isEmpty()) { unlock(); toast("No camera found"); return }
            if (lensIdx >= ids.size) lensIdx = 0
            chars = cm.getCameraCharacteristics(ids[lensIdx])
            configure()
            runOnUiThread { applyTransform(); syncSliders() }
            cm.openCamera(ids[lensIdx], stateCb, bg)
        } catch (e: Exception) { unlock(); Log.e(tag, "open", e); toast("Open failed: ${e.message}") }
    }

    private fun closeCamera() {
        val got = openLock.tryAcquire(2500, TimeUnit.MILLISECONDS)
        if (got) lockHeld.set(true)
        try {
            session?.close(); session = null
            camera?.close(); camera = null
            jpegReader?.close(); jpegReader = null
            builder = null
        } finally { unlock() }
    }

    private fun switchCamera(flip: Boolean) {
        if (recording) return
        if (flip) { facing = if (facing == CameraCharacteristics.LENS_FACING_BACK) CameraCharacteristics.LENS_FACING_FRONT else CameraCharacteristics.LENS_FACING_BACK; lensIdx = 0 }
        else lensIdx++
        regions = null; zoom = 1f
        closeCamera(); openCamera()
    }

    private fun cycleRes() {
        if (videoSizes.isEmpty() || recording) return
        val i = (videoSizes.indexOf(videoSize) + 1) % videoSizes.size
        resH = videoSizes[i].height
        cam { closeCamera(); openCamera() }
    }

    private fun cycleFps() {
        if (recording) return
        fps = fpsList[(fpsList.indexOf(fps) + 1) % fpsList.size]
        expNs = expNs.coerceIn(shutMin(), shutMax())
        refresh(); labels(); syncSliders()
    }

    private fun encoderExists(mime: String) = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
        .any { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }

    private fun clampBitrate(bps: Int, mime: String): Int = try {
        MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos
            .firstOrNull { it.isEncoder && it.supportedTypes.any { t -> t.equals(mime, true) } }
            ?.getCapabilitiesForType(mime)?.videoCapabilities?.bitrateRange?.clamp(bps) ?: bps
    } catch (e: Exception) { bps }

    /** Reads real hardware capabilities; nothing is assumed. */
    private fun configure() {
        val ch = chars!!
        val map = ch.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP)!!
        val all = (map.getOutputSizes(MediaRecorder::class.java) ?: emptyArray()).toList()
        var v = all.filter { it.width * 9 == it.height * 16 && it.height in 720..2160 }.sortedBy { it.height }
        if (v.isEmpty()) v = all.filter { it.height in 480..2160 }.sortedBy { it.width * it.height }
        if (v.isEmpty()) v = listOf(all.maxByOrNull { it.width * it.height } ?: Size(1280, 720))
        videoSizes = v
        videoSize = v.firstOrNull { it.height == resH } ?: v.minByOrNull { abs(it.height - resH) }!!
        resH = videoSize.height
        fun sameAspect(s: Size) = s.width * videoSize.height == s.height * videoSize.width
        val prev = (map.getOutputSizes(SurfaceTexture::class.java) ?: emptyArray()).filter { it.width <= 1920 }
        previewSize = prev.filter { sameAspect(it) }.maxByOrNull { it.width * it.height } ?: prev.maxByOrNull { it.width * it.height } ?: Size(1280, 720)
        val jp = (map.getOutputSizes(ImageFormat.JPEG) ?: emptyArray()).toList()
        photoSize = jp.filter { sameAspect(it) }.maxByOrNull { it.width * it.height } ?: jp.maxByOrNull { it.width * it.height } ?: previewSize

        val ranges = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)
        val minDur = map.getOutputMinFrameDuration(MediaRecorder::class.java, videoSize)
        fpsList = listOf(24, 25, 30, 60).filter { f ->
            (ranges?.any { it.lower <= f && it.upper >= f } ?: (f <= 30)) && (minDur <= 0 || 1e9 / minDur >= f - 0.5)
        }.ifEmpty { listOf(30) }
        if (fps !in fpsList) fps = if (30 in fpsList) 30 else fpsList.last()

        manualOk = ch.get(CameraCharacteristics.REQUEST_AVAILABLE_CAPABILITIES)?.contains(CameraMetadata.REQUEST_AVAILABLE_CAPABILITIES_MANUAL_SENSOR) == true
        isoRange = ch.get(CameraCharacteristics.SENSOR_INFO_SENSITIVITY_RANGE) ?: Range(100, 100)
        expRange = ch.get(CameraCharacteristics.SENSOR_INFO_EXPOSURE_TIME_RANGE) ?: Range(1_000_000L, 1_000_000L)
        minFocus = ch.get(CameraCharacteristics.LENS_INFO_MINIMUM_FOCUS_DISTANCE) ?: 0f
        evRange = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_RANGE) ?: Range(0, 0)
        evStep = ch.get(CameraCharacteristics.CONTROL_AE_COMPENSATION_STEP)?.toFloat() ?: 0f
        maxZoom = min(8f, ch.get(CameraCharacteristics.SCALER_AVAILABLE_MAX_DIGITAL_ZOOM) ?: 1f)
        maxAf = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AF) ?: 0
        maxAe = ch.get(CameraCharacteristics.CONTROL_MAX_REGIONS_AE) ?: 0
        if (!manualOk) manualExp = false
        if (minFocus <= 0f) manualFocus = false
        iso = iso.coerceIn(isoRange.lower, isoRange.upper)
        expNs = expNs.coerceIn(shutMin(), shutMax())
        evIdx = evIdx.coerceIn(evRange.lower, evRange.upper)
        zoom = zoom.coerceIn(1f, maxZoom)

        val awb = ch.get(CameraCharacteristics.CONTROL_AWB_AVAILABLE_MODES)?.toList() ?: emptyList()
        wbModes = listOf(
            CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB", CameraMetadata.CONTROL_AWB_MODE_DAYLIGHT to "DAYLIGHT",
            CameraMetadata.CONTROL_AWB_MODE_CLOUDY_DAYLIGHT to "CLOUDY", CameraMetadata.CONTROL_AWB_MODE_INCANDESCENT to "TUNGSTEN",
            CameraMetadata.CONTROL_AWB_MODE_FLUORESCENT to "FLUORESCENT"
        ).filter { it.first in awb }.ifEmpty { listOf(CameraMetadata.CONTROL_AWB_MODE_AUTO to "AWB") }
        wbIdx = wbIdx.coerceIn(0, wbModes.size - 1)
        val st = mutableListOf("OFF")
        if (ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_OPTICAL_STABILIZATION)?.contains(CameraMetadata.LENS_OPTICAL_STABILIZATION_MODE_ON) == true) st += "OIS"
        if (ch.get(CameraCharacteristics.CONTROL_AVAILABLE_VIDEO_STABILIZATION_MODES)?.contains(CameraMetadata.CONTROL_VIDEO_STABILIZATION_MODE_ON) == true) st += "EIS"
        stabOpts = st; stabIdx = stabIdx.coerceIn(0, st.size - 1)
        val f = ch.get(CameraCharacteristics.LENS_INFO_AVAILABLE_FOCAL_LENGTHS)?.firstOrNull()
        val sz = ch.get(CameraCharacteristics.SENSOR_INFO_PHYSICAL_SIZE)
        lensLabel = if (f != null && sz != null) "${(f * 43.27 / hypot(sz.width.toDouble(), sz.height.toDouble())).roundToInt()}mm" else "LENS"
        val l = mutableListOf("OFF")
        val tm = ch.get(CameraCharacteristics.TONEMAP_AVAILABLE_TONE_MAP_MODES)?.toList() ?: emptyList()
        if (CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE in tm && (ch.get(CameraCharacteristics.TONEMAP_MAX_CURVE_POINTS) ?: 0) >= 5)
            l += listOf("CONTRAST", "TEAL-ORANGE", "WARM", "COOL", "FADED")
        val fx = ch.get(CameraCharacteristics.CONTROL_AVAILABLE_EFFECTS)?.toList() ?: emptyList()
        if (CameraMetadata.CONTROL_EFFECT_MODE_MONO in fx) l += "B&W"
        if (CameraMetadata.CONTROL_EFFECT_MODE_SEPIA in fx) l += "SEPIA"
        if (CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE in fx) l += "NEGATIVE"
        if (CameraMetadata.CONTROL_EFFECT_MODE_AQUA in fx) l += "AQUA"
        if (CameraMetadata.CONTROL_EFFECT_MODE_POSTERIZE in fx) l += "POSTERIZE"
        looks = l; lookIdx = lookIdx.coerceIn(0, l.size - 1)
        if (hevc && !hevcOk) hevc = false
    }

    /** Screen rotation relative to sensor; also used for JPEG and video orientation (landscape-locked UI). */
    private fun rel(): Int {
        val sens = chars?.get(CameraCharacteristics.SENSOR_ORIENTATION) ?: 90
        @Suppress("DEPRECATION") val disp = when (windowManager.defaultDisplay.rotation) { Surface.ROTATION_90 -> 90; Surface.ROTATION_180 -> 180; Surface.ROTATION_270 -> 270; else -> 0 }
        return if (facing == CameraCharacteristics.LENS_FACING_FRONT) (sens + disp) % 360 else (sens - disp + 360) % 360
    }

    private fun cropRect(): Rect {
        val a = chars!!.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
        val w = (a.width() / zoom).toInt(); val h = (a.height() / zoom).toInt()
        return Rect(a.centerX() - w / 2, a.centerY() - h / 2, a.centerX() + w / 2, a.centerY() + h / 2)
    }

    private fun applyControls(b: CaptureRequest.Builder, record: Boolean) {
        val ch = chars ?: return
        b.set(CaptureRequest.CONTROL_MODE, CameraMetadata.CONTROL_MODE_AUTO)
        b.set(CaptureRequest.SCALER_CROP_REGION, cropRect())
        val fr = ch.get(CameraCharacteristics.CONTROL_AE_AVAILABLE_TARGET_FPS_RANGES)?.filter { it.lower <= fps && it.upper >= fps }
            ?.minByOrNull { it.upper - it.lower }
        if (manualExp) {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_OFF)
            b.set(CaptureRequest.SENSOR_SENSITIVITY, iso)
            b.set(CaptureRequest.SENSOR_EXPOSURE_TIME, expNs.coerceIn(shutMin(), shutMax()))
            b.set(CaptureRequest.SENSOR_FRAME_DURATION, frameNs)
        } else {
            b.set(CaptureRequest.CONTROL_AE_MODE, CameraMetadata.CONTROL_AE_MODE_ON)
            b.set(CaptureRequest.CONTROL_AE_EXPOSURE_COMPENSATION, evIdx)
            if (fr != null) b.set(CaptureRequest.CONTROL_AE_TARGET_FPS_RANGE, fr)
        }
        if (manualFocus && minFocus > 0f) {
            b.set(CaptureRequest.CONTROL_AF_MODE, CameraMetadata.CONTROL_AF_MODE_OFF)
            b.set(CaptureRequest.LENS_FOCUS_DISTANCE, focusP * minFocus)
        } else b.set(CaptureRequest.CONTROL_AF_MODE, if (record) CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_VIDEO else CameraMetadata.CONTROL_AF_MODE_CONTINUOUS_PICTURE)
        b.set(CaptureRequest.CONTROL_AWB_MODE, wbModes[wbIdx.coerceIn(0, wbModes.size - 1)].first)
        val stab = stabOpts[stabIdx.coerceIn(0, stabOpts.size - 1)]
        if ("OIS" in stabOpts) b.set(CaptureRequest.LENS_OPTICAL_STABILIZATION_MODE, if (stab == "OIS") 1 else 0)
        if ("EIS" in stabOpts) b.set(CaptureRequest.CONTROL_VIDEO_STABILIZATION_MODE, if (stab == "EIS" && record) 1 else 0)
        val look = looks[lookIdx.coerceIn(0, looks.size - 1)]
        b.set(CaptureRequest.CONTROL_EFFECT_MODE, when (look) {
            "B&W" -> CameraMetadata.CONTROL_EFFECT_MODE_MONO; "SEPIA" -> CameraMetadata.CONTROL_EFFECT_MODE_SEPIA
            "NEGATIVE" -> CameraMetadata.CONTROL_EFFECT_MODE_NEGATIVE; "AQUA" -> CameraMetadata.CONTROL_EFFECT_MODE_AQUA
            "POSTERIZE" -> CameraMetadata.CONTROL_EFFECT_MODE_POSTERIZE; else -> CameraMetadata.CONTROL_EFFECT_MODE_OFF
        })
        lookCurve(look)?.let { b.set(CaptureRequest.TONEMAP_MODE, CameraMetadata.TONEMAP_MODE_CONTRAST_CURVE); b.set(CaptureRequest.TONEMAP_CURVE, it) }
        regions?.let {
            if (maxAf > 0) b.set(CaptureRequest.CONTROL_AF_REGIONS, it)
            if (maxAe > 0 && !manualExp) b.set(CaptureRequest.CONTROL_AE_REGIONS, it)
        }
    }

    private fun lookCurve(n: String): TonemapCurve? {
        fun c(r: FloatArray, g: FloatArray = r, b: FloatArray = r) = TonemapCurve(r, g, b)
        return when (n) {
            "CONTRAST" -> c(floatArrayOf(0f, 0f, 0.25f, 0.18f, 0.5f, 0.5f, 0.75f, 0.82f, 1f, 1f))
            "TEAL-ORANGE" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.20f, 0.5f, 0.52f, 0.75f, 0.85f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.74f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.31f, 0.5f, 0.48f, 0.75f, 0.68f, 1f, 1f))
            "WARM" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f))
            "COOL" -> c(
                floatArrayOf(0f, 0f, 0.25f, 0.22f, 0.5f, 0.45f, 0.75f, 0.70f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.25f, 0.5f, 0.50f, 0.75f, 0.75f, 1f, 1f),
                floatArrayOf(0f, 0f, 0.25f, 0.28f, 0.5f, 0.55f, 0.75f, 0.80f, 1f, 1f))
            "FADED" -> c(floatArrayOf(0f, 0.08f, 0.25f, 0.28f, 0.5f, 0.52f, 0.75f, 0.76f, 1f, 0.95f))
            else -> null
        }
    }

    private fun refresh() = cam {
        val b = builder ?: return@cam
        val s = session ?: return@cam
        applyControls(b, recording)
        s.setRepeatingRequest(b.build(), captureCb, bg)
    }

    private val captureCb = object : CameraCaptureSession.CaptureCallback() {
        override fun onCaptureCompleted(s: CameraCaptureSession, r: CaptureRequest, res: TotalCaptureResult) {
            val now = SystemClock.elapsedRealtime()
            if (now - lastTel < 250) return
            lastTel = now
            val i = res.get(CaptureResult.SENSOR_SENSITIVITY)
            val e = res.get(CaptureResult.SENSOR_EXPOSURE_TIME)
            val fd = res.get(CaptureResult.LENS_FOCUS_DISTANCE)
            val af = when (res.get(CaptureResult.CONTROL_AF_STATE)) {
                CaptureResult.CONTROL_AF_STATE_FOCUSED_LOCKED, CaptureResult.CONTROL_AF_STATE_PASSIVE_FOCUSED -> "AF:OK"
                CaptureResult.CONTROL_AF_STATE_NOT_FOCUSED_LOCKED -> "AF:FAIL"
                CaptureResult.CONTROL_AF_STATE_ACTIVE_SCAN, CaptureResult.CONTROL_AF_STATE_PASSIVE_SCAN -> "AF:SCAN"
                else -> ""
            }
            tel = "ISO ${i ?: "-"}  1/${e?.let { (1e9 / it).roundToInt() } ?: "-"}  FOCUS " +
                (fd?.let { if (it < 0.05f) "INF" else String.format(Locale.US, "%.2fm", 1f / it) } ?: "-") + " $af  " +
                "${videoSize.width}x${videoSize.height} ${fps}p ${if (hevc) "HEVC" else "AVC"} ${mbps}M  " + String.format(Locale.US, "%.1fx", zoom)
        }
    }

    @Suppress("DEPRECATION")
    private fun startPreview() {
        val c = camera ?: return
        val st = tv.surfaceTexture ?: return
        session?.close(); session = null
        st.setDefaultBufferSize(previewSize.width, previewSize.height)
        val ps = Surface(st)
        jpegReader?.close()
        val jr = ImageReader.newInstance(photoSize.width, photoSize.height, ImageFormat.JPEG, 2)
        jr.setOnImageAvailableListener({ savePhoto(it) }, bg)
        jpegReader = jr
        c.createCaptureSession(listOf(ps, jr.surface), object : CameraCaptureSession.StateCallback() {
            override fun onConfigured(s: CameraCaptureSession) {
                if (camera == null) return
                session = s
                val b = c.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW)
                b.addTarget(ps); builder = b
                applyControls(b, false)
                try { s.setRepeatingRequest(b.build(), captureCb, bg) } catch (e: Exception) { Log.e(tag, "preview", e) }
            }
            override fun onConfigureFailed(s: CameraCaptureSession) { toast("Preview configuration failed") }
        }, bg)
    }

    private fun tapFocus(nx0: Float, ny0: Float) {
        overlay.tapX = nx0; overlay.tapY = ny0; overlay.tapAt = System.currentTimeMillis()
        cam {
            val ch = chars ?: return@cam
            val crop = cropRect()
            val (nx, ny) = when (rel()) {
                90 -> ny0 to (1 - nx0)
                180 -> (1 - nx0) to (1 - ny0)
                270 -> (1 - ny0) to nx0
                else -> nx0 to ny0
            }
            val half = (min(crop.width(), crop.height()) * 0.07f).toInt()
            val cx = crop.left + (nx * crop.width()).toInt(); val cy = crop.top + (ny * crop.height()).toInt()
            val a = ch.get(CameraCharacteristics.SENSOR_INFO_ACTIVE_ARRAY_SIZE)!!
            val x = (cx - half).coerceIn(a.left, a.right - 2 * half - 1); val y = (cy - half).coerceIn(a.top, a.bottom - 2 * half - 1)
            regions = arrayOf(MeteringRectangle(x, y, 2 * half, 2 * half, 1000))
            val b = builder ?: return@cam
            val s = session ?: return@cam
            applyControls(b, recording)
            if (!manualFocus && maxAf > 0) {
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_CANCEL); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_START); s.capture(b.build(), null, bg)
                b.set(CaptureRequest.CONTROL_AF_TRIGGER, CameraMetadata.CONTROL_AF_TRIGGER_IDLE)
            }
            s.setRepeatingRequest(b.build(), captureCb, bg)
        }
    }

    // ───────────────────────── photo ─────────────────────────
    private fun takePhoto() = cam {
        if (recording) return@cam
        val c = camera ?: return@cam
        val s = session ?: return@cam
        val jr = jpegReader ?: return@cam
        val b = c.createCaptureRequest(CameraDevice.TEMPLATE_STILL_CAPTURE)
        b.addTarget(jr.surface)
        applyControls(b, false)
        b.set(CaptureRequest.JPEG_ORIENTATION, rel())
        b.set(CaptureRequest.JPEG_QUALITY, 95.toByte())
        s.capture(b.build(), null, bg)
    }

    private fun savePhoto(r: ImageReader) {
        val img = r.acquireNextImage() ?: return
        try {
            val buf = img.planes[0].buffer
            val bytes = ByteArray(buf.remaining()); buf.get(bytes)
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "PHIRMS_${stamp()}.jpg")
                put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PHIRMS")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, cv)!!
            contentResolver.openOutputStream(uri)!!.use { it.write(bytes) }
            contentResolver.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            lastUri = uri; lastMime = "image/jpeg"
            toast("Photo saved to Pictures/PHIRMS")
        } catch (e: Exception) { Log.e(tag, "photo", e); toast("Photo save failed: ${e.message}") } finally { img.close() }
    }

    private fun stamp() = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())

    // ───────────────────────── video ─────────────────────────
    private fun toggleRecord() = cam { if (recording) stopRecording() else startRecording() }

    @Suppress("DEPRECATION")
    private fun startRecording() {
        val c = camera ?: return
        if (recording) return
        if (freeBytes() < 500L * 1024 * 1024) { toast("Need at least 500 MB free storage"); return }
        try {
            audioMeter.stop()
            val audio = hasPerm(Manifest.permission.RECORD_AUDIO)
            if (!audio) toast("No microphone permission – recording video only")
            val rec = if (Build.VERSION.SDK_INT >= 31) MediaRecorder(this) else MediaRecorder()
            recorder = rec
            val cv = ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, "PHIRMS_${stamp()}.mp4")
                put(MediaStore.MediaColumns.MIME_TYPE, "video/mp4")
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Movies/PHIRMS")
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }
            val uri = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, cv)!!
            recUri = uri
            recPfd = contentResolver.openFileDescriptor(uri, "w")
            if (audio) rec.setAudioSource(MediaRecorder.AudioSource.MIC)
            rec.setVideoSource(MediaRecorder.VideoSource.SURFACE)
            rec.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            rec.setOutputFile(recPfd!!.fileDescriptor)
            val mime = if (hevc) "video/hevc" else "video/avc"
            rec.setVideoEncodingBitRate(clampBitrate(mbps * 1_000_000, mime))
            rec.setVideoFrameRate(fps)
            rec.setVideoSize(videoSize.width, videoSize.height)
            rec.setVideoEncoder(if (hevc) MediaRecorder.VideoEncoder.HEVC else MediaRecorder.VideoEncoder.H264)
            if (audio) { rec.setAudioEncoder(MediaRecorder.AudioEncoder.AAC); rec.setAudioEncodingBitRate(192_000); rec.setAudioSamplingRate(48_000) }
            rec.setOrientationHint(rel())
            rec.setOnErrorListener { _, _, _ -> cam { stopRecording() } }
            rec.setOnInfoListener { _, what, _ ->
                if (what == MediaRecorder.MEDIA_RECORDER_INFO_MAX_FILESIZE_REACHED) cam { stopRecording() }
            }
            rec.prepare()

            val st = tv.surfaceTexture ?: throw IllegalStateException("no preview surface")
            st.setDefaultBufferSize(previewSize.width, previewSize.height)
            val ps = Surface(st)
            val rs = rec.surface
            val b = c.createCaptureRequest(CameraDevice.TEMPLATE_RECORD)
            b.addTarget(ps); b.addTarget(rs)
            applyControls(b, true)
            session?.close(); session = null
            c.createCaptureSession(listOf(ps, rs), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(s: CameraCaptureSession) {
                    try {
                        session = s; builder = b
                        s.setRepeatingRequest(b.build(), captureCb, bg)
                        rec.start()
                        recStart = SystemClock.elapsedRealtime()
                        recording = true
                        runOnUiThread { setRecUi(true) }
                    } catch (e: Exception) { Log.e(tag, "rec start", e); toast("Recording failed: ${e.message}"); stopRecording() }
                }
                override fun onConfigureFailed(s: CameraCaptureSession) { toast("Recording not supported with these settings"); stopRecording() }
            }, bg)
        } catch (e: Exception) {
            Log.e(tag, "prepare", e); toast("Cannot start recording: ${e.message}"); stopRecording()
        }
    }

    private fun stopRecording(restart: Boolean = true) {
        if (!recording && recorder == null) return
        var ok = recording
        recording = false
        try { session?.stopRepeating(); session?.abortCaptures() } catch (e: Exception) {}
        recorder?.let { r ->
            try { r.stop() } catch (e: RuntimeException) { ok = false; Log.e(tag, "stop", e) }
            try { r.reset() } catch (e: Exception) {}
            r.release()
        }
        recorder = null
        try { recPfd?.close() } catch (e: Exception) {}
        recPfd = null
        recUri?.let { u ->
            if (ok) {
                contentResolver.update(u, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
                lastUri = u; lastMime = "video/mp4"
                toast("Video saved to Movies/PHIRMS")
            } else { contentResolver.delete(u, null, null) }
        }
        recUri = null
        runOnUiThread { setRecUi(false) }
        if (restart) {
            if (hasPerm(Manifest.permission.RECORD_AUDIO)) audioMeter.start()
            startPreview()
        }
    }
}
